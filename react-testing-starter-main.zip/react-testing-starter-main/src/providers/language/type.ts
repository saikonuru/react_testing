export type Language = "en" | "es";
