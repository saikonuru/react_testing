import Onboarding from "../components/Onboarding";

const PlaygroundPage = () => {
  return <Onboarding />;
};

export default PlaygroundPage;
